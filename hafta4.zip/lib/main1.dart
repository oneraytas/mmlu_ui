import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Resim Geçişi',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: ResimGecisi(),
    );
  }
}

class ResimGecisi extends StatefulWidget {
  @override
  _ResimGecisiState createState() => _ResimGecisiState();
}

class _ResimGecisiState extends State<ResimGecisi> {
  int _currentIndex = 0;
  final List<String> _images = [
    'assets/images/image1.jpeg',
    'assets/images/image2.jpeg',
    'assets/images/image3.jpeg'
  ];

  void _nextImage() {
    setState(() {
      _currentIndex = (_currentIndex + 1) % _images.length;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Resim Geçişi'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Container(width: 250, child: Image.asset(_images[_currentIndex])),
            const SizedBox(height: 20),
            ElevatedButton(
              style: const ButtonStyle(
                backgroundColor: MaterialStatePropertyAll<Color>(Colors.green),
              ),
              onPressed: _nextImage,
              child: const Text('Sonraki Resim'),
            ),
          ],
        ),
      ),
    );
  }
}
