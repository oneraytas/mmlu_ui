import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: const Text('Flutter Row, Stack, Expand Örneği'),
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: <Widget>[
                  Container(
                    padding: const EdgeInsets.all(10.0),
                    color: Colors.red,
                    child: const Text('Kırmızı Kutu'),
                  ),
                  Container(
                    padding: const EdgeInsets.all(10.0),
                    color: const Color.fromARGB(255, 54, 63, 244),
                    child: const Text('Mavi Kutu'),
                  ),
                  Container(
                    padding: const EdgeInsets.all(10.0),
                    color: const Color.fromARGB(255, 73, 244, 54),
                    child: const Text('Yeşil Kutu'),
                  )
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
