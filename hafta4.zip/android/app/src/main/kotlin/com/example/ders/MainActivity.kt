package com.example.ders

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
